package com.cg.junitdemo;

import static org.junit.Assert.*;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumJuint {

	 static WebDriver driver;
	 private StringBuffer verificationErrors = new StringBuffer();


	
	@Before
	public void start(){
		
    //launching browser
	driver = new FirefoxDriver();
	
	//Navigating to URL
	driver.navigate().to("https://demo.opencart.com/");
	
	//Implicit Wait
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    driver.manage().window().maximize();
	}
	@BeforeClass
	public static void method1(){
		System.out.println("Before class");
	}
	
	@AfterClass
	public static void method2(){
		System.out.println("After class");
	}
	
    @Test
    public void testing() throws InterruptedException{
    
    	//Verifying the Title
       //Verifying the Title
    		
    	 try {
    	      assertEquals("The OpenCart demo store", driver.getTitle());
    	    } catch (Error e) {
    	      verificationErrors.append(e.toString());
    	    }

    		      
    		    //Clicking on '0 item(s)-$0.00' button
    		      driver.findElement(By.cssSelector(".btn.btn-inverse.btn-block.btn-lg.dropdown-toggle")).click();
    		      
    		    //Verifying the message
    		     
    		      

    		      try {
    		        assertEquals("Your shopping cart is empty!", driver.findElement(By.className("text-center")).getText());
    		      } catch (Error e) {
    		        verificationErrors.append(e.toString());
    		      }
    		       
    		    //Clicking on 'Currency'
    		       driver.findElement(By.xpath("html/body/nav/div/div[1]/form/div/button")).click();
    		    //Selecting 'Pound Sterling ' Value
    		       Thread.sleep(1000);
    		       driver.findElement(By.xpath("html/body/nav/div/div[1]/form/div/button")).click();
    		       
    		    //Valiadting the selected currency
    		       try {
       		        assertEquals("�", driver.findElement(By.cssSelector(".currency-select.btn.btn-link.btn-block")).getText());
       		      } catch (Error e) {
       		        verificationErrors.append(e.toString());
       		      }
       		       
    		 
    		    //Clicking on Contact Butoon
    		       driver.findElement(By.cssSelector(".fa.fa-phone")).click();
    		       
    		    //verifying the Heading 'Contact Us'
    		     
    		       try {
    		    	      assertEquals("Contact Us", driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText());
    		    	    } catch (Error e) {
    		    	      verificationErrors.append(e.toString());
    		    	    }

    		       
    		     //Enterind Details in Cotact form
    		       //Entering name
    		       driver.findElement(By.id("input-name")).clear();
    		       driver.findElement(By.id("input-name")).sendKeys("ABC");
    		       
    		       //Entering invalid email
    		       driver.findElement(By.id("input-email")).clear();
    		       driver.findElement(By.id("input-email")).sendKeys("igate.c.n");
    		       
    		       //entering submit button
    		       driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
    		       
    		       //Verifying Error message
    		       
    		       try {
 		    	      assertEquals("E-Mail Address does not appear to be valid!", driver.findElement(By.cssSelector("div.text-danger")).getText());
 		    	    } catch (Error e) {
 		    	      verificationErrors.append(e.toString());
 		    	    }

    		       
    		       //Entering valid email
    		       driver.findElement(By.id("input-email")).clear();
    		       driver.findElement(By.id("input-email")).sendKeys("ABC@gmail.com");
    		       
    		       //entering text in Enquiry text box
    		       driver.findElement(By.id("input-enquiry")).clear();
    		       driver.findElement(By.id("input-enquiry")).sendKeys("I am ABC . Working in capgemini.");
    		     
    		       Thread.sleep(3000);
    		       //driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset/div[4]/div/input")).clear();
    		       
    		     
    		       //entering captacha manually
    		       Scanner scan = new Scanner(System.in);
    		       System.out.println("Enter Captcha");
    		       String captcha = scan.next();
    		       
    		       driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset/div[4]/div/input")).sendKeys(captcha);
    		       
    		       //Clicking on submit
    		       driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input")).click();

    		       //verifying message 'your enquiry has been successfully sent to the store owner
    		       try {
  		    	      assertEquals("Your enquiry has been successfully sent to the store owner!", driver.findElement(By.xpath("html/body/div[2]/div/div/p")).getText());
  		    	    } catch (Error e) {
  		    	      verificationErrors.append(e.toString());
  		    	    }
    		       
    		       //clicking on Brand in Extras
    		       driver.findElement(By.linkText("Continue")).click();
    		       driver.findElement(By.linkText("Brands")).click();
    		       
    		       //Verifying title 'Find your favorite brand '
    		     
    		       
    		       try {
   		    	      assertEquals("Find Your Favorite Brand", driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText());
   		    	    } catch (Error e) {
   		    	      verificationErrors.append(e.toString());
   		    	    }
    		       //clicking on sony and validating price
    		       driver.findElement(By.linkText("Sony")).click();
    		      
    		       
    		       try {
    		    	      assertEquals("1,093.94� Ex Tax: 910.10�", driver.findElement(By.cssSelector("p.price")).getText());
    		    	    } catch (Error e) {
    		    	      verificationErrors.append(e.toString());
    		    	    }
    		       
    		       //clicking on adde to cart and verifying message
    		       driver.findElement(By.xpath("html/body/div[2]/div/div/div[3]/div/div/div[3]/button[1]")).click();
    	          if((driver.findElement(By.cssSelector("div.alert.alert-success")).getText()).contains("Success: You have added "))
    	        	   System.out.println("It is added to shopping cart");
    	           else 
    	        	   System.out.println("it is  added to shopping cart");
    		       
    		       
    	           
    	           //clicking on list button
    	           driver.findElement(By.xpath("(//button[@type='button'])[5]")).click();
    	           
    	           //verifying sony vaio 
    	         
    	           try {
 		    	      assertEquals("Sony VAIO", driver.findElement(By.linkText("Sony VAIO")).getText());
 		    	    } catch (Error e) {
 		    	      verificationErrors.append(e.toString());
 		    	    }
    	           
    	           
    	        
    	 
       
    }
    @After
    public void close(){
    	System.out.println("closing the browser");
    	driver.close();
    }

}
