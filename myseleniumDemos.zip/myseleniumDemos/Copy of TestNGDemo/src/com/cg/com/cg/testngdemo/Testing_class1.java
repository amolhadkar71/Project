package com.cg.com.cg.testngdemo;



import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Testing_class1 {
	
	@BeforeClass
	public void start(){
		System.out.println("Start server");
	}
	
	@BeforeMethod
	public void login(){
		System.out.println("Login to Application");
	}
	
    @Test(priority=1)
    public void Test1() {
	   System.out.println("Book Flight");
    }
  
    @Test(priority=2)
    public void Test2() {
	   System.out.println("Update Flight");
    }
    @AfterMethod
    public void logout(){
    	System.out.println("Log out from application");
    }
    @AfterClass
    public void stop(){
    	System.out.println("Stop server and close connections");
    }
  
}
