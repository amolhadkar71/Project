package com.cg.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class JunitDemo {
	static WebDriver driver;
	@BeforeClass
	public static void launching(){
		
		//step1 launching the browser
		 driver = new FirefoxDriver();
		
		//step2 navigate to application
		driver.navigate().to("https://enterprise-demo.orangehrmlive.com/auth/login");
		driver.manage().window().maximize();
	}
	@Before
	public void before(){
		System.out.println("Before");
		System.out.println(driver.getTitle());
		Assert.assertEquals("OrangeHRM", driver.getTitle());
	}

@Test
public void test1(){
		
	//step3 to find the element and perform the action
	driver.findElement(By.xpath("//*[@id='txtUsername']")).sendKeys("Admin");
	driver.findElement(By.name("txtPassword")).sendKeys("admin");
	driver.findElement(By.cssSelector("#btnLogin")).click();
}
	
	@After
	public void after(){
		System.out.println("After");
	}
	 @AfterClass
	  public static void closing(){
	      driver.close();
	  }


}
