package com.cg.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Lab3UsingJunit.class, Lab4UsingJunit.class })
public class AllTests {

}
