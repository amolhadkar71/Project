package com.cg.pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class sel_class2Demo {

	public static void main(String[] args) {
		
		//step1 launching the browser
		WebDriver driver = new FirefoxDriver();
		
		//step2 navigate to application
		driver.navigate().to("https://enterprise-demo.orangehrmlive.com/auth/login");
		driver.manage().window().maximize();
		
		//step3 to find the element and perform the action
		driver.findElement(By.xpath("//*[@id='txtUsername']")).sendKeys("Admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin");
		driver.findElement(By.cssSelector("#btnLogin")).click();
		
		// click on hyperlink
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.id("ohrmList_chkSelectRecord_36")).click();

		//find selection box
		WebElement adminrole = driver.findElement(By.id("searchSystemUser_adminRole"));
		
		//create an obj of select class
		Select sel = new Select(adminrole);
		
		//select value for options
		sel.selectByVisibleText("HR Manager");
		sel.selectByValue("28");
		sel.selectByIndex(0);
		sel.selectByIndex(3);
		driver.close();
		System.out.println("Execution is complted");
	}

}
