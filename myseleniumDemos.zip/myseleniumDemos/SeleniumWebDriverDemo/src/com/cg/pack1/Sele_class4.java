package com.cg.pack1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sele_class4 {

	public static void main(String[] args) {

			//step1 launching the browser
			WebDriver driver = new FirefoxDriver();
					
			//step2 navigate to application
		    driver.navigate().to("https://enterprise-demo.orangehrmlive.com/auth/login");
			//driver.manage().window().maximize();
			
			String expectedTitle = "OrangeRM";
			String actualTitle = driver.getTitle();
			System.out.println(actualTitle);
			
			//System.out.println(actualTitle.equals(expectedTitle));
	        if(actualTitle.equals(expectedTitle)==true)
	        	System.out.println("Expected result is matched with actual result");
	        else
	        	System.out.println("Expected result is not matched with actual result");
			
			System.out.println(driver.getCurrentUrl());
			
			System.out.println(driver.getPageSource());
			
			System.out.println((driver.getPageSource()).contains("document"));

		


	}

}
