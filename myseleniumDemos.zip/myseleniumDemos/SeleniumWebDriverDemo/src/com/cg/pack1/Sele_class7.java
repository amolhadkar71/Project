package com.cg.pack1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sele_class7 {

public static void main(String[] args) {
		
		//step1 launching the browser
		WebDriver driver = new FirefoxDriver();
				
		//step2 navigate to application
	    driver.navigate().to("http://www.seleniumframework.com/practiceform/");
		//driver.manage().window().maximize();
	
	    List<WebElement> linkElements = driver.findElements(By.tagName("a"));
	    String[] linkTexts = new String[linkElements.size()];
		//System.out.println(driver.getPageSource());
	    int i = 0 ;
	    
	    //extract the link texts of each link element
	    for(WebElement e : linkElements)
	    {
	    	linkTexts[i] = e.getText();
	    	System.out.println("The Hyperlink - text "+e.getText());
	    	i++;
	    }
	   
    }
}

