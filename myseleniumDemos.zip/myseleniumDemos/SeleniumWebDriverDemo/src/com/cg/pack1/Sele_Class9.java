package com.cg.pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Sele_Class9 {
	static String driverpath = "C:\\selenium library\\";
	public static void main(String[] args) throws InterruptedException {
	
		//launching the browser
				System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
				WebDriver driver = new ChromeDriver();
		
		driver.get("file:///C:/Users/srpokala/Desktop/iframe.html");
		driver.manage().window().maximize();
		driver.switchTo().frame("wsc");
		driver.findElement(By.xpath("html/body/div[6]/div[1]/div[1]/a[1]")).click();
		Thread.sleep(1000);
		
		driver.switchTo().defaultContent();
		Thread.sleep(1000);
		driver.switchTo().frame("tv");
		driver.findElement(By.xpath("//*[@id='top-menu']/div[3]/a/span[2]")).click();
		driver.switchTo().defaultContent();
			
		
		

	}

}
