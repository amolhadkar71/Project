package com.cg.pack1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Sele_class6 {

	public static void main(String[] args) throws InterruptedException {
		

		//step1 launching the browser
		WebDriver driver = new FirefoxDriver();
				
		//step2 navigate to application
	    driver.navigate().to("http://www.seleniumframework.com/practiceform/");
		//driver.manage().window().maximize();
	    driver.manage().window().setPosition(new Point(50,50));
	    
	    driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MICROSECONDS);
		
	    WebElement textarea = driver.findElement(By.id("vfb-10"));
	    textarea.clear();
	    textarea.sendKeys("Hii! This is Sravani Pokala");
	    String idval = textarea.getText();
	    System.out.println(idval);
	    
	    WebElement text = driver.findElement(By.name("vfb-9"));
	    System.out.println(text.getText());
	    text.clear();
	    text.sendKeys("This is text attribute");

	  Thread.sleep(30000000);
		driver.findElement(By.id("vfb-6-0" )).click();
		driver.findElement(By.id("vfb-6-1" )).click();
		driver.findElement(By.id("vfb-6-2")).click();

		 driver.findElement(By.id("vfb-7-2")).click();
		 
		 WebElement url = driver.findElement(By.id("vfb-11"));
		 url.sendKeys("www.seleniumframework.com/practiceform/");
		 
		 WebElement select = driver.findElement(By.id("vfb-12"));
		 
		 Select sel = new Select(select);
		 sel.selectByVisibleText("Option 2");
		 
		 WebElement ver = driver.findElement(By.xpath("//input[@id='vfb-3']"));
		 ver.sendKeys("13");
		 
		 driver.findElement(By.id("vfb-4")).click();
		 
		 
	}

}
