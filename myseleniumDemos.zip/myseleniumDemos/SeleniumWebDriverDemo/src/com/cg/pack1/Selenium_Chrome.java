package com.cg.pack1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selenium_Chrome {
	static String driverpath = "C:\\selenium library\\";
	
	public static void main(String[] args) {
		
		//launching the browser
		System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//navigate to application
				driver.get("https://enterprise-demo.orangehrmlive.com/auth/login");
	}
	
}
