package com.cg.pack1;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sele_class8 {

	//static String driverpath = "C:\\Selenium library\\";
	
	public static void main(String[] args) throws InterruptedException {
	
		//System.setProperty("webdriver.ie.driver", driverpath+"IEDriverServer.exe");
		WebDriver driver = new FirefoxDriver();
		//driver.get("http://demo.opencart.com/");
		driver.get("http://www.seleniumframework.com/practiceform/");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	/*	System.out.println("Hiiiii! This is Sravani Pokala");
		
		driver.findElement(By.cssSelector("textarea#vfb-10")).sendKeys("select text area");
		driver.findElement(By.cssSelector("input[name=vfb-9]")).sendKeys("Text box");
		driver.findElement(By.cssSelector("input.vfb-text[name=vfb-9]")).sendKeys("Sravani");
		driver.findElement(By.cssSelector("input[name=vfb-9][id=vfb-9]"));
		
		driver.findElement(By.cssSelector("#alert")).click();
		
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		//wait.until(ExpectedConditions.alertIsPresent());
		
		//to perform acton on alert
		Alert alt = driver.switchTo().alert();
		System.out.println(alt.getText());
		
		
		 
		if(alt.getText().equals("Please share this website with your friends and in your organization."))
			System.out.println("Expected alert is same as Actual Alert");
		else
			System.out.println("Expected alert is not same as Actual alert");

		alt.accept();
		//alt.dismiss();
		
		//driver.findElement()*/
		 
		//to get parent window id
		String parent_Window = driver.getWindowHandle();
		System.out.println("Before switching to child");
		
		//to click on New Browser Window button
		driver.findElement(By.xpath("//*[@id='button1']")).click();
		
		//to get child window id
		
		Set<String> s1 = driver.getWindowHandles();
		
		Iterator<String> it = s1.iterator();
		
		while(it.hasNext())
		{
			String child_Window = it.next();
		
		if(!parent_Window.equalsIgnoreCase(child_Window))
		{
			
			driver.switchTo().window(child_Window);
			//Thread.sleep(10000);
			System.out.println("Title of child window"+driver.getTitle());
			driver.manage().window().maximize();
			driver.findElement(By.linkText("Choosing an Automation Solution")).click();
			//Thread.sleep(1000);
			driver.close();
			
		}
		}
	
		driver.switchTo().window(parent_Window);
		System.out.println("back to parent window");
		
		driver.close();
		
	}
		

	
	
}
