package com.cg.pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sele_class5 {

	public static void main(String[] args) {
		
		//step1 launching the browser
		WebDriver driver = new FirefoxDriver();
				
		//step2 navigate to application
	    driver.navigate().to("https://enterprise-demo.orangehrmlive.com/auth/login");
		//driver.manage().window().maximize();
		
	    //get text method
	    WebElement  lin = driver.findElement(By.linkText("OrangeHRM, Inc"));
	    System.out.println(lin.getText());
	    
	    driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Admin");
	    driver.findElement(By.id("txtPassword")).sendKeys("admin");
	    driver.findElement(By.className("button")).sendKeys(Keys.ENTER);
	   /* //get attribute method
	    WebElement att = driver.findElement(By.id("txtUsername"));
	    att.clear();
	    att.sendKeys("Admin");
	    String typeval = att.getAttribute("type");
	    System.out.println(typeval);
	    
        System.out.println(att.getAttribute("value"));*/
	}

}
