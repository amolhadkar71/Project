package com.cg.pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Sele_classDemo {
	

	public static void main(String[] args) {
		
		//step1 launching the browser
		WebDriver driver = new FirefoxDriver();
		
		//step2 navigate to application
		//driver.get("https://enterprise-demo.orangehrmlive.com/auth/login");
		driver.navigate().to("https://enterprise-demo.orangehrmlive.com/auth/login");
		driver.manage().window().maximize();
		
		/*//step3 to find the element and perform the action
		//driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		//driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		//driver.findElement(By.cssSelector("#txtUsername")).sendKeys("Admin");
		driver.findElement(By.xpath("//*[@id='txtUsername']")).sendKeys("Admin");
		/*driver.findElement(By.id("txtPassword")).sendKeys("admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin");
		driver.findElement(By.cssSelector("#txtPassword")).sendKeys("admin");*/
		driver.findElement(By.xpath("//*[@id='txtPassword']")).sendKeys("admin");
		/*driver.findElement(By.id("btnLogin")).click();
		driver.findElement(By.name("Submit")).click();
		driver.findElement(By.className("button")).click();
	    driver.findElement(By.xpath("//*[@id='btnLogin']")).click();
		driver.findElement(By.cssSelector("#btnLogin")).click(); */
		
		//step3:1 find the element
		/*WebElement un = driver.findElement(By.id("txtUsername"));
		WebElement pwd = driver.findElement(By.id("txtPassword"));
		WebElement login = driver.findElement(By.id("btnLogin"));*/
		
		WebElement un = driver.findElement(By.name("txtUsername"));
		WebElement pwd = driver.findElement(By.name("txtPassword"));
		WebElement login = driver.findElement(By.name("Submit"));
		
		//step3 : 2 perform action
		un.clear();
		un.sendKeys("Admin");
		pwd.clear();
		pwd.sendKeys("admin");
		login.click();
		
		/*//navigation commands
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();*/
	    
		
		//step4 close the browser
		driver.close();
		//driver.quit();

	}

}
