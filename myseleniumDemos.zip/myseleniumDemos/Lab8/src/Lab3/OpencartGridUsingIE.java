package Lab3;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class OpencartGridUsingIE {
	
	static WebDriver driver;
	static String driverpath = "C:\\selenium library\\";
	
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		System.setProperty("webdriver.ie.driver",driverpath+"IEDriverServer.exe");
		
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setBrowserName("InternetExplorer");
		capabilities.setPlatform(Platform.ANY);
	
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities);
		
	
		
		
		//Navigate to application
		  driver.navigate().to("http://demo.opencart.com/");
	      driver.manage().window().maximize();
	      
	    //part1 LaunchApplication
	      //Verificaiton of title
	      String expectedTitle = "The OpenCart demo store";
	      String actualTitle = driver.getTitle();
	      if(expectedTitle.equals(actualTitle))
	    	  System.out.println("Expected title is equal to Actual title");
	      else
	    	  System.out.println("Expected title is not equal to Actual Title");
	      
	      
	      //Click on My Account drop down
	      driver.findElement(By.linkText("My Account")).click();
	      
	      //select Register from drop down
	      driver.findElement(By.linkText("Register")).click();
	      
	      //Verify the heading Register Account
	      String regacc = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	      String regacc1 = "Register Account";
	      if(regacc.equals(regacc1))
	    	  System.out.println("Expected heading is equal to actual heading");
	      else
	    	  System.out.println("Expected Headingis not equal to Actual Heading");
	      
	      
	      
	      //verify warning message
	      String actualWarn = driver.findElement(By.xpath("html/body/div[2]/div[1]")).getText();
        String expectedWarn = "Warning: You must agree to the Privacy Policy!";
        if(actualWarn.equals(expectedWarn))
      	  System.out.println("Warning is verified");
        else
      	  System.out.println("Warning is not verified");
        
        //part 2
        //Enter data in 'First Name'
        driver.findElement(By.id("input-firstname")).sendKeys("Sravani");
        
       /* //Verifying the firstname
        String firstName = driver.findElement(By.xpath("//*[@id='account']/div[2]/div/div")).getText();
        String firstName1 = "First Name must be between 1 and 32 characters!";
        if(firstName.equals(firstName1))
      	  System.out.println("First Name is verified");
        else
      	  System.out.println("First Name is not verified");*/
        
        //Enter data in 'Last Name'
        driver.findElement(By.id("input-lastname")).sendKeys("Pokala");
        
       /* //Verifying the last name
        String lastname = driver.findElement(By.xpath("//*[@id='account']/div[3]/div/div")).getText();
        String lastname1 = "Last Name must be between 1 and 32 characters!";
        if(lastname.equals(lastname1))
      	  System.out.println("Last Name is Verified");
        else
      	  System.out.println("Last Name is not verified");*/
        
        //Enter valid E-mail
        driver.findElement(By.id("input-email")).sendKeys("pokalasravani86@gmail.com");
        
        //Enter Telephone Number
        driver.findElement(By.id("input-telephone" )).sendKeys("9642543692");
        
        
        //part 3
        //Enter 'Address 1' which should contain characters between 3 and 128
        driver.findElement(By.xpath("//*[@id='input-address-1']")).sendKeys("CapGemini");
        
        //Enter 'city' which hould contain characters between 2 and 128
        driver.findElement(By.xpath("//*[@id='input-city']")).sendKeys("Bangalore");
        
        //Enter 'post code' which should contain characters between 2 and 10
        driver.findElement(By.id("input-postcode")).sendKeys("523240");
        
        //Select 'India' from Country' Drop down
        WebElement country = driver.findElement(By.xpath("//*[@id='input-country']"));
        Select sel = new Select(country);
        sel.selectByVisibleText("India");
        // WebElement region1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-zone")));
        //Select 'Region/State' from dropdown
        WebElement region = driver.findElement(By.id("input-zone"));
        Select sel1 = new Select(region);
        sel1.selectByVisibleText("Karnataka");
        
        
        
        //driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[1]")).click();
        driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
        
	     // driver.close();
	      
	      //part 4 
	      //Enter 'password' which must be between 4 and 20 characters
	      driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys("sravani18@");
	      
	      //Enter 'Password Confirm'
	      driver.findElement(By.id("input-confirm")).sendKeys("sravani18@");
	      Thread.sleep(3000);
	      
	      //click on yes radio button
	      driver.findElement(By.xpath("//*[@id='content']/form/fieldset[4]/div/div/label[1]/input")).click();
	      
	      //click on check box for 'I have read and agree to the privacy polcy'
	      driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input[1]")).click();
	      
	      //click on continue button
	      driver.findElement(By.xpath(".//*[@id='content']/form/div/div/input[2]")).click();
	      
	      //Verify message 'your account has been created'
	     String create = "Your Account Has Been Created!";
	      String create1 = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
	      if(create.equals(create1))
	    	  System.out.println("Account has created");
	      else
	    	  System.out.println("Account has not created");
	      
	      //click on 'continue'
	      driver.findElement(By.xpath("html/body/div[2]/div/div/div/div/a")).click();
	      
	      //click on link 'View your order history under 'My orders'
	      driver.findElement(By.xpath("html/body/div[2]/div/div/ul[2]/li[1]/a")).click();
        
 

	}

}
