package com.cg.seleniumGrid.com;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class OpencartGridUsingIE {
	
	static WebDriver driver;
	static String driverpath = "C:\\selenium library\\";
	
	public static void main(String[] args) throws InterruptedException, MalformedURLException {
		System.setProperty("webdriver.ie.driver",driverpath+"IEDriverServer.exe");
		
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setBrowserName("InternetExplorer");
		capabilities.setPlatform(Platform.ANY);
	
		driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities);
		
	
		
		
		//Navigating to URL
		driver.navigate().to("https://demo.opencart.com/");
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	    
	    //Verifying the Title
	    String expectedTitle = "The OpenCart demo store";
	    String actualTitle = driver.getTitle();
	      if(expectedTitle.equals(actualTitle))
	    	  System.out.println("Expected title is equal to Actual title");
	      else
	    	  System.out.println("Expected title is not equal to Actual Title");
	      
	    //Clicking on '0 item(s)-$0.00' button
	      driver.findElement(By.cssSelector(".btn.btn-inverse.btn-block.btn-lg.dropdown-toggle")).click();
	      
	    //Verifying the message
	      String expectedMsg = "Your shopping cart is empty!";
	      String actualMsg = driver.findElement(By.className("text-center")).getText();
	       if(expectedMsg.equals(actualMsg))
	    	   System.out.println("Your shopping cart is empty! is Verified");
	       else
	    	   System.out.println("Your shopping cart is empty! is not Verified");
	       
	    //Clicking on 'Currency'
	       driver.findElement(By.xpath("html/body/nav/div/div[1]/form/div/button")).click();
	    //Selecting 'Pound Sterling ' Value
	       Thread.sleep(1000);
	       driver.findElement(By.xpath("html/body/nav/div/div[1]/form/div/button")).click();
	       
	    //Valiadting the selected currency
	       String expectedCur = "�";
	       String actualCur = driver.findElement(By.cssSelector(".currency-select.btn.btn-link.btn-block")).getText();
	        if(expectedCur.contains(actualCur))
	        	System.out.println("Currency is Verified");
	        else
	        	System.out.println("Currency is not verified");
	 
	    //Clicking on Contact Butoon
	       driver.findElement(By.cssSelector(".fa.fa-phone")).click();
	       
	    //verifying the Heading 'Contact Us'
	       String expectedHead = "Contact Us";
	       String actualHead = driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText();
	       if(expectedHead.equals(actualHead))
	    	   System.out.println("Heading is Verified");
	       else
	    	   System.out.println("Heading is not verified");
	       
	     //Enterind Details in Cotact form
	       //Entering name
	       driver.findElement(By.id("input-name")).clear();
	       driver.findElement(By.id("input-name")).sendKeys("ABC");
	       
	       //Entering invalid email
	       driver.findElement(By.id("input-email")).clear();
	       driver.findElement(By.id("input-email")).sendKeys("igate.c.n");
	       
	       //entering submit button
	       driver.findElement(By.cssSelector("input.btn.btn-primary")).click();
	       
	       //Verifying Error message
	       String expectederrMsg = "E-Mail Address does not appear to be valid!";
	       String actualErrMsg = driver.findElement(By.cssSelector("div.text-danger")).getText();
	       if(expectederrMsg.equals(actualErrMsg))
	    	   System.out.println("Error Message is Verified");
	       else
	    	   System.out.println("Error message is not verified");
	       
	       //Entering valid email
	       driver.findElement(By.id("input-email")).clear();
	       driver.findElement(By.id("input-email")).sendKeys("ABC@gmail.com");
	       
	       //entering text in Enquiry text box
	       driver.findElement(By.id("input-enquiry")).clear();
	       driver.findElement(By.id("input-enquiry")).sendKeys("I am ABC . Working in capgemini.");
	     
	       Thread.sleep(3000);
	       //driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset/div[4]/div/input")).clear();
	       
	     
	       //entering captacha manually
	       Scanner scan = new Scanner(System.in);
	       System.out.println("Enter Captcha");
	       String captcha = scan.next();
	       
	       driver.findElement(By.xpath("html/body/div[2]/div/div/form/fieldset/div[4]/div/input")).sendKeys(captcha);
	       
	       //Clicking on submit
	       driver.findElement(By.xpath("html/body/div[2]/div/div/form/div/div/input")).click();

	       //verifying message 'your enquiry has been successfully sent to the store owner
	       if(("Your enquiry has been successfully sent to the store owner!").equals(driver.findElement(By.cssSelector("#content > p")).getText()))
	    	   System.out.println("Message is Verified");
	       else
	    	   System.out.println("Message is not verified");
	       
	       //clicking on Brand in Extras
	       driver.findElement(By.linkText("Continue")).click();
	       driver.findElement(By.linkText("Brands")).click();
	       
	       //Verifying title 'Find your favorite brand '
	       String expectedBrand = "Find Your Favorite Brand";
	       String actualBrand = driver.findElement(By.xpath("html/body/div[2]/div/div/h1")).getText();
	       if(expectedBrand.equals(actualBrand))
	    	   System.out.println("Your Favorite Brand is selected");
	       else
	    	   System.out.println("Your Favorite Brand is not selected");
	       
	       //clicking on sony and validating price
	       driver.findElement(By.linkText("Sony")).click();
	       String expectedCost = "1,093.94� Ex Tax: 910.10�";
	       String actualCost = driver.findElement(By.cssSelector("p.price")).getText();
	       if(expectedCost.equals(actualCost))
	    	   System.out.println("Your Expected cost is same as Actual Cost");
	       else
	    	   System.out.println("Your Expected cost is not same as Actual Cost");
	       
	       //clicking on adde to cart and verifying message
	       driver.findElement(By.xpath("html/body/div[2]/div/div/div[3]/div/div/div[3]/button[1]")).click();
           if((driver.findElement(By.cssSelector("div.alert.alert-success")).getText()).contains("Success: You have added "))
        	   System.out.println("It is added to shopping cart");
           else 
        	   System.out.println("it is  added to shopping cart");
           
           //clicking on list button
           driver.findElement(By.xpath("(//button[@type='button'])[5]")).click();
           
           //verifying sony vaio 
           if("Sony VAIO".equals(driver.findElement(By.linkText("Sony VAIO")).getText()))
        	   System.out.println("Sony Vaio is added ");
           else
        	   System.out.println("sony vaio is not added");
           
           
        
 

	}

}
