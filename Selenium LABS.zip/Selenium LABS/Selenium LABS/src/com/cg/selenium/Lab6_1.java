package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lab6_1 {
	public static String driverpath="C:\\Users\\AMHADKAR\\Desktop\\";
	public static void main(String[] args) throws InterruptedException {
		
		//step1 launching the browser
		System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//1.Enter URL.
				driver.get("https://demo.opencart.com");
				
				//2.Verify Title:
				String title = driver.getTitle();
				System.out.println(title);
				String expected_title = "Your Store";
				System.out.println("Title Equals: "+title.equals(expected_title));
				
				//3.Click on 'My Account' dropdown.
				driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
				
				//4.Select 'Register' from dropdown:
				driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a")).click();
				
				//5.�Register Account� page will open up, verify the heading �Register Account�:
				boolean b = driver.findElement(By.xpath("//*[@id='content']/h1")).isDisplayed();
				System.out.println("Heading verify: "+b);
				
				//6.Click on 'Continue' button at the bottom of the page
				driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
			
				//7.Verify warning message 'Warning: You must agree to the Privacy Policy!'.
				String str =driver.findElement(By.xpath("//*[@id='account-register']/div[1]")).getText();
				System.out.println("Warning msg verify: "+str.equals("Warning: You must agree to the Privacy Policy!"));
				
				
				
				driver.findElement(By.name("firstname")).sendKeys("Amolllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll");
				driver.findElement(By.name("lastname")).sendKeys("Amolllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll");
				//8.Enter valid 'E-mail':
				driver.findElement(By.id("input-email")).sendKeys("amolhadkar7171@gmail.com");
						
				//9.Enter 'Telephone' which must be between 3 and 32 characters:
				driver.findElement(By.id("input-telephone")).sendKeys("022-7898563241564645645645645678987987985645648798765648787956456487985648798156412556489648798545456484874856");
						
				//10.Click on 'Continue' button at the bottom of the page
				driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]")).click();
					
				
				
	}
}
